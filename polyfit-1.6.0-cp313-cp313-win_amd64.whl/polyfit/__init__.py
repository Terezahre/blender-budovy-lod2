# Alias for the PyPolyFit module
import os

try:
    from .PyPolyFit import *
except ImportError:
    from PyPolyFit import *
